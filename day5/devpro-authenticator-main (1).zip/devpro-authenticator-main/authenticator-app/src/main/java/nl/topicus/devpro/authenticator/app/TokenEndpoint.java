package nl.topicus.devpro.authenticator.app;

import java.io.IOException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.nimbusds.oauth2.sdk.OAuth2Error;
import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.TokenErrorResponse;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.http.JakartaServletUtils;
import nl.topicus.devpro.authenticator.server.TokenEndpointService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The endpoint the client application calls, with its own credentials, to trade an authorization
 * code for tokens. No browser involved, so there is nothing to render and nowhere to redirect.
 */
@RestController
public class TokenEndpoint
{
	public static final String PATH = "/oauth2/token";

	private final TokenEndpointService tokens;

	public TokenEndpoint(TokenEndpointService tokens)
	{
		this.tokens = tokens;
	}

	@PostMapping(PATH)
	public void issueTokens(HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		TokenResponse tokenResponse;
		try
		{
			// The SDK knows what a token request looks like on the wire, including both ways a
			// client may present its secret, so nothing here reads form fields or Basic headers.
			tokenResponse =
				tokens.exchange(TokenRequest.parse(JakartaServletUtils.createHTTPRequest(request)));
		}
		catch (ParseException e)
		{
			tokenResponse = new TokenErrorResponse(e.getErrorObject() == null
				? OAuth2Error.INVALID_REQUEST.setDescription(e.getMessage()) : e.getErrorObject());
		}
		JakartaServletUtils.applyHTTPResponse(tokenResponse.toHTTPResponse(), response);
	}
}
