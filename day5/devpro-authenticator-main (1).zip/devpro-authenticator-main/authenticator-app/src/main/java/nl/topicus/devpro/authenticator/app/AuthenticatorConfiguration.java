package nl.topicus.devpro.authenticator.app;

import java.net.URI;
import java.time.Clock;
import java.util.List;
import java.util.Set;

import nl.topicus.devpro.authenticator.AuthorizationServerSettings;
import nl.topicus.devpro.authenticator.jwt.SigningKey;
import nl.topicus.devpro.authenticator.jwt.TokenIssuer;
import nl.topicus.devpro.authenticator.jwt.TokenVerifier;
import nl.topicus.devpro.authenticator.resource.BearerTokenFilter;
import nl.topicus.devpro.authenticator.server.AuthorizationCodeStore;
import nl.topicus.devpro.authenticator.server.AuthorizationEndpointService;
import nl.topicus.devpro.authenticator.server.ClientRegistry;
import nl.topicus.devpro.authenticator.server.RegisteredClient;
import nl.topicus.devpro.authenticator.server.TokenEndpointService;
import nl.topicus.devpro.authenticator.server.UserAccount;
import nl.topicus.devpro.authenticator.server.UserDirectory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Wires the framework independent classes together. This is the only Spring specific part of the
 * authorization server: swapping it for CDI producers or hand written construction changes nothing
 * about how tokens are issued or verified.
 */
@Configuration
public class AuthenticatorConfiguration
{
	private static final String REALM = "devpro-authenticator";

	@Bean
	public Clock clock()
	{
		return Clock.systemUTC();
	}

	@Bean
	public AuthorizationServerSettings
			authorizationServerSettings(@Value("${authenticator.issuer}") URI issuer)
	{
		return AuthorizationServerSettings.forIssuer(issuer);
	}

	@Bean
	public SigningKey signingKey()
	{
		return SigningKey.generate();
	}

	@Bean
	public TokenIssuer tokenIssuer(AuthorizationServerSettings settings, SigningKey signingKey,
			Clock clock)
	{
		return new TokenIssuer(settings, signingKey, clock);
	}

	/**
	 * The resource server is handed only the public half of the key, which is what a separately
	 * deployed one would have fetched from the jwks_uri.
	 */
	@Bean
	public TokenVerifier tokenVerifier(AuthorizationServerSettings settings, SigningKey signingKey,
			Clock clock)
	{
		return new TokenVerifier(settings, signingKey.publicKeys(), clock);
	}

	@Bean
	public AuthorizationCodeStore authorizationCodeStore(AuthorizationServerSettings settings,
			Clock clock)
	{
		return new AuthorizationCodeStore(settings, clock);
	}

	/**
	 * The one client of this example. Its secret is in the source because there is nothing to
	 * protect here; a real registration lives wherever the application keeps its integrations.
	 */
	@Bean
	public ClientRegistry clientRegistry()
	{
		return new ClientRegistry(List.of(new RegisteredClient("devpro-client", "devpro-secret",
			Set.of(URI.create("http://localhost:8080/callback")), Set.of("openid", "greeting.read"),
			true)));
	}

	@Bean
	public UserDirectory userDirectory()
	{
		return new UserDirectory(List.of(new UserAccount("student", "devpro", "DevPro Student")));
	}

	@Bean
	public AuthorizationEndpointService authorizationEndpointService(ClientRegistry clients,
			AuthorizationCodeStore codes, Clock clock)
	{
		return new AuthorizationEndpointService(clients, codes, clock);
	}

	@Bean
	public TokenEndpointService tokenEndpointService(AuthorizationServerSettings settings,
			ClientRegistry clients, AuthorizationCodeStore codes, TokenIssuer tokens)
	{
		return new TokenEndpointService(settings, clients, codes, tokens);
	}

	@Bean
	public FilterRegistrationBean<BearerTokenFilter> bearerTokenFilter(TokenVerifier verifier)
	{
		FilterRegistrationBean<BearerTokenFilter> registration = new FilterRegistrationBean<>(
			new BearerTokenFilter(verifier, REALM, Set.of(GreetingResource.REQUIRED_SCOPE)));
		registration.addUrlPatterns("/api/*");
		return registration;
	}
}
