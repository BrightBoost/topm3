package nl.topicus.devpro.authenticator.app;

import java.util.LinkedHashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import nl.topicus.devpro.authenticator.jwt.VerifiedAccessToken;
import nl.topicus.devpro.authenticator.resource.BearerTokenFilter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The protected resource, and the reason the rest of this project exists. It contains no security
 * logic at all: by the time it runs, the filter has already established who is calling.
 */
@RestController
public class GreetingResource
{
	public static final String REQUIRED_SCOPE = "greeting.read";

	@GetMapping("/api/greeting")
	public Map<String, Object> greeting(HttpServletRequest request)
	{
		VerifiedAccessToken token = BearerTokenFilter.tokenOf(request);

		Map<String, Object> greeting = new LinkedHashMap<>();
		greeting.put("message", "Hello " + token.subject());
		greeting.put("clientId", token.clientId());
		greeting.put("scopes", token.scopes());
		greeting.put("expiresAt", token.expiresAt().toString());
		return greeting;
	}
}
