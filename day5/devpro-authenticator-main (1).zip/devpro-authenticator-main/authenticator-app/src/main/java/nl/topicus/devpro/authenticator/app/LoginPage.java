package nl.topicus.devpro.authenticator.app;

import java.nio.charset.StandardCharsets;

import nl.topicus.devpro.authenticator.server.OAuth2RequestException;
import nl.topicus.devpro.authenticator.server.ValidatedAuthorizationRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.HtmlUtils;

/**
 * The two pages the authorization endpoint can show a user. Hand written HTML keeps the example
 * free of a template engine; a real login screen is the application's own, not the protocol's.
 */
public class LoginPage
{
	private static final String FORM = """
			<!DOCTYPE html>
			<html lang="en">
			<head>
			<meta charset="utf-8">
			<title>Sign in</title>
			</head>
			<body>
			<h1>Sign in</h1>
			<p>%s wants to sign you in and is asking for: %s</p>
			%s
			<form method="post" action="%s">
			<input type="hidden" name="authorization_request" value="%s">
			<p><label>Username <input name="username" autofocus></label></p>
			<p><label>Password <input name="password" type="password"></label></p>
			<p><button type="submit">Sign in</button></p>
			</form>
			</body>
			</html>
			""";

	private static final String REFUSAL =
		"""
				<!DOCTYPE html>
				<html lang="en">
				<head>
				<meta charset="utf-8">
				<title>Request refused</title>
				</head>
				<body>
				<h1>Request refused</h1>
				<p>%s</p>
				<p>This is reported here instead of to the application because the request did not say where
				it could safely be sent back to.</p>
				</body>
				</html>
				""";

	private LoginPage()
	{
	}

	/**
	 * @param authorizationRequest
	 *            the original query string, carried through the login as a hidden field. The server
	 *            keeps no session, so this is how the request survives until the password arrives.
	 */
	public static ResponseEntity<String> form(String action, String authorizationRequest,
			ValidatedAuthorizationRequest request, String message)
	{
		return html(HttpStatus.OK,
			FORM.formatted(escape(request.client().clientId()),
				escape(String.join(", ", request.scopes())), messageParagraph(message),
				escape(action), escape(authorizationRequest)));
	}

	public static ResponseEntity<String> refusal(OAuth2RequestException failure)
	{
		return html(HttpStatus.BAD_REQUEST, REFUSAL.formatted(escape(failure.getMessage())));
	}

	private static String messageParagraph(String message)
	{
		return message == null ? "" : "<p><strong>" + escape(message) + "</strong></p>";
	}

	private static ResponseEntity<String> html(HttpStatus status, String body)
	{
		return ResponseEntity.status(status)
			.contentType(new MediaType(MediaType.TEXT_HTML, StandardCharsets.UTF_8))
			.body(body);
	}

	private static String escape(String value)
	{
		return HtmlUtils.htmlEscape(value == null ? "" : value);
	}
}
