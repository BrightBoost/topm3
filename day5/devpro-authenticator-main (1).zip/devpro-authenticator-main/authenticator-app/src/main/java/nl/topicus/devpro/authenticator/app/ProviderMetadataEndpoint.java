package nl.topicus.devpro.authenticator.app;

import nl.topicus.devpro.authenticator.AuthorizationServerSettings;
import nl.topicus.devpro.authenticator.jwt.SigningKey;
import nl.topicus.devpro.authenticator.server.ClientRegistry;
import nl.topicus.devpro.authenticator.server.ProviderMetadata;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * What this server publishes about itself: the discovery document a client library configures
 * itself from, and the public keys anything can verify a token with.
 */
@RestController
public class ProviderMetadataEndpoint
{
	private final AuthorizationServerSettings settings;

	private final ClientRegistry clients;

	private final SigningKey signingKey;

	public ProviderMetadataEndpoint(AuthorizationServerSettings settings, ClientRegistry clients,
			SigningKey signingKey)
	{
		this.settings = settings;
		this.clients = clients;
		this.signingKey = signingKey;
	}

	@GetMapping(path = "/.well-known/openid-configuration",
			produces = MediaType.APPLICATION_JSON_VALUE)
	public String openIdConfiguration()
	{
		return ProviderMetadata.of(settings, clients.knownScopes()).toJSONObject().toJSONString();
	}

	@GetMapping(path = "/oauth2/jwks", produces = MediaType.APPLICATION_JSON_VALUE)
	public String jwkSet()
	{
		return signingKey.publicKeys().toString();
	}
}
