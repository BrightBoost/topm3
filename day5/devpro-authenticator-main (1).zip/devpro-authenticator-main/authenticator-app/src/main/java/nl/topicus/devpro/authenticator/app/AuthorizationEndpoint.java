package nl.topicus.devpro.authenticator.app;

import java.net.URI;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;

import nl.topicus.devpro.authenticator.server.AuthorizationEndpointService;
import nl.topicus.devpro.authenticator.server.OAuth2RequestException;
import nl.topicus.devpro.authenticator.server.UserAccount;
import nl.topicus.devpro.authenticator.server.UserDirectory;
import nl.topicus.devpro.authenticator.server.ValidatedAuthorizationRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * The endpoint the user's browser visits. It is the only part of the flow a human sees, and the
 * only part where the answer is a redirect rather than a response body.
 */
@Controller
public class AuthorizationEndpoint
{
	public static final String PATH = "/oauth2/authorize";

	private final AuthorizationEndpointService authorizations;

	private final UserDirectory users;

	public AuthorizationEndpoint(AuthorizationEndpointService authorizations, UserDirectory users)
	{
		this.authorizations = authorizations;
		this.users = users;
	}

	@GetMapping(PATH)
	public ResponseEntity<String> requestAuthorization(HttpServletRequest request)
	{
		String query = request.getQueryString();
		try
		{
			return LoginPage.form(PATH, query, authorizations.validate(authorizations.parse(query)),
				null);
		}
		catch (OAuth2RequestException e)
		{
			return refuse(e);
		}
	}

	@PostMapping(PATH)
	public ResponseEntity<String> submitCredentials(
			@RequestParam("authorization_request") String query,
			@RequestParam("username") String username, @RequestParam("password") String password)
	{
		try
		{
			// The request went through the browser between the two calls, so it is validated again
			// rather than trusted.
			ValidatedAuthorizationRequest request =
				authorizations.validate(authorizations.parse(query));

			Optional<UserAccount> user = users.authenticate(username, password);
			if (user.isEmpty())
				return LoginPage.form(PATH, query, request, "Unknown username or password");

			return redirectTo(authorizations.approve(request, user.get().username()));
		}
		catch (OAuth2RequestException e)
		{
			return refuse(e);
		}
	}

	private ResponseEntity<String> refuse(OAuth2RequestException failure)
	{
		return authorizations.rejection(failure)
			.map(this::redirectTo)
			.orElseGet(() -> LoginPage.refusal(failure));
	}

	private ResponseEntity<String> redirectTo(URI location)
	{
		return ResponseEntity.status(HttpStatus.FOUND).location(location).build();
	}
}
