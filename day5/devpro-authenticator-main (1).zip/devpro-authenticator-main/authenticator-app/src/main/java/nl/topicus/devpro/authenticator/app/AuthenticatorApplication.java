package nl.topicus.devpro.authenticator.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Runs the authorization server and the resource server in one process. They are the same
 * application here only to keep the example small; the two halves share nothing but the public key.
 */
@SpringBootApplication
public class AuthenticatorApplication
{
	public static void main(String[] args)
	{
		SpringApplication.run(AuthenticatorApplication.class, args);
	}
}
