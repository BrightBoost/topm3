package nl.topicus.devpro.authenticator.app;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;

import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.oauth2.sdk.AuthorizationCode;
import com.nimbusds.oauth2.sdk.AuthorizationCodeGrant;
import com.nimbusds.oauth2.sdk.AuthorizationSuccessResponse;
import com.nimbusds.oauth2.sdk.ResponseType;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.auth.ClientSecretBasic;
import com.nimbusds.oauth2.sdk.auth.Secret;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.id.State;
import com.nimbusds.oauth2.sdk.pkce.CodeChallengeMethod;
import com.nimbusds.oauth2.sdk.pkce.CodeVerifier;
import com.nimbusds.openid.connect.sdk.AuthenticationRequest;
import com.nimbusds.openid.connect.sdk.Nonce;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponse;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponseParser;
import com.nimbusds.openid.connect.sdk.token.OIDCTokens;

/**
 * Walks the authorization code flow the way a client application would: the two browser steps with
 * a plain HTTP client, the two OAuth messages with the same SDK the server itself uses.
 */
public class AuthorizationCodeFlow
{
	private final HttpClient browser =
		HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();

	private final URI baseUri;

	private final ClientID clientId;

	private final Secret clientSecret;

	private final URI redirectUri;

	public AuthorizationCodeFlow(URI baseUri, String clientId, String clientSecret, URI redirectUri)
	{
		this.baseUri = baseUri;
		this.clientId = new ClientID(clientId);
		this.clientSecret = new Secret(clientSecret);
		this.redirectUri = redirectUri;
	}

	public Tokens run(String username, String password, Scope scope) throws Exception
	{
		// The verifier never leaves this object until the token request; only its SHA-256 hash
		// travels through the browser.
		CodeVerifier codeVerifier = new CodeVerifier();
		State state = new State();
		Nonce nonce = new Nonce();

		AuthenticationRequest request =
			new AuthenticationRequest.Builder(ResponseType.CODE, scope, clientId, redirectUri)
				.endpointURI(baseUri.resolve(AuthorizationEndpoint.PATH))
				.state(state)
				.nonce(nonce)
				.codeChallenge(codeVerifier, CodeChallengeMethod.S256)
				.build();

		assertThat(openLoginForm(request.toURI())).contains("name=\"password\"");

		AuthorizationCode code =
			submitCredentials(request.toURI().getRawQuery(), username, password, state);

		return requestTokens(code, codeVerifier, nonce);
	}

	private String openLoginForm(URI authorizationRequest) throws IOException, InterruptedException
	{
		HttpResponse<String> response = browser.send(
			HttpRequest.newBuilder(authorizationRequest).GET().build(), BodyHandlers.ofString());

		assertThat(response.statusCode()).as("login form").isEqualTo(200);
		return response.body();
	}

	private AuthorizationCode submitCredentials(String authorizationRequest, String username,
			String password, State state) throws Exception
	{
		String form = "authorization_request=" + encode(authorizationRequest) + "&username="
			+ encode(username) + "&password=" + encode(password);

		HttpResponse<String> response =
			browser.send(HttpRequest.newBuilder(baseUri.resolve(AuthorizationEndpoint.PATH))
				.header("Content-Type", "application/x-www-form-urlencoded")
				.POST(HttpRequest.BodyPublishers.ofString(form))
				.build(), BodyHandlers.ofString());

		assertThat(response.statusCode()).as("credentials accepted").isEqualTo(302);
		URI location = URI.create(response.headers().firstValue("Location").orElseThrow());
		AuthorizationSuccessResponse success = AuthorizationSuccessResponse.parse(location);

		// The state is handed back untouched. A client that does not compare it will happily
		// redeem a code that was obtained in someone else's browser.
		assertThat(success.getState()).isEqualTo(state);
		return success.getAuthorizationCode();
	}

	private Tokens requestTokens(AuthorizationCode code, CodeVerifier codeVerifier, Nonce nonce)
			throws Exception
	{
		TokenRequest request = new TokenRequest(baseUri.resolve(TokenEndpoint.PATH),
			new ClientSecretBasic(clientId, clientSecret),
			new AuthorizationCodeGrant(code, redirectUri, codeVerifier));

		TokenResponse response = OIDCTokenResponseParser.parse(request.toHTTPRequest().send());
		assertThat(response.indicatesSuccess()).as("token response %s", response).isTrue();

		OIDCTokens tokens = ((OIDCTokenResponse) response).getOIDCTokens();
		if (tokens.getIDTokenString() != null)
			assertThat(nonceOf(tokens.getIDTokenString())).isEqualTo(nonce.getValue());
		return new Tokens(tokens.getAccessToken().getValue(), tokens.getIDTokenString());
	}

	private String nonceOf(String idToken) throws ParseException
	{
		return SignedJWT.parse(idToken).getJWTClaimsSet().getStringClaim("nonce");
	}

	private String encode(String value)
	{
		return URLEncoder.encode(value, StandardCharsets.UTF_8);
	}

	public record Tokens(String accessToken, String idToken)
	{
	}
}
