package nl.topicus.devpro.authenticator.app;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

import com.nimbusds.oauth2.sdk.Scope;
import nl.topicus.devpro.authenticator.app.AuthorizationCodeFlow.Tokens;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;

/**
 * Proves the point of the whole project: the protected endpoint answers nothing without a token,
 * and answers normally with one that came out of a full authorization code flow.
 */
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class ProtectedEndpointTest
{
	private static final URI REDIRECT_URI = URI.create("http://localhost:8080/callback");

	@Value("${local.server.port}")
	private int port;

	private final HttpClient client = HttpClient.newHttpClient();

	@Test
	void theGreetingIsRefusedWithoutAToken() throws Exception
	{
		HttpResponse<String> response = requestGreeting(null);

		assertThat(response.statusCode()).isEqualTo(401);
		// Nothing was presented, so there is nothing wrong with it either: no error code.
		assertThat(authenticateHeaderOf(response)).startsWith("Bearer")
			.contains("realm=\"devpro-authenticator\"")
			.doesNotContain("error=");
	}

	@Test
	void theGreetingIsRefusedWithAnInventedToken() throws Exception
	{
		HttpResponse<String> response = requestGreeting("not.a.token");

		assertThat(response.statusCode()).isEqualTo(401);
		assertThat(authenticateHeaderOf(response)).contains("error=\"invalid_token\"");
	}

	@Test
	void theGreetingIsServedWithATokenFromTheFlow() throws Exception
	{
		Tokens tokens = flow().run("student", "devpro", new Scope("openid", "greeting.read"));

		HttpResponse<String> response = requestGreeting(tokens.accessToken());

		assertThat(response.statusCode()).isEqualTo(200);
		assertThat(response.body()).contains("Hello student")
			.contains("devpro-client")
			.contains("greeting.read");
	}

	@Test
	void theGreetingIsRefusedWhenTheTokenDoesNotCoverIt() throws Exception
	{
		Tokens tokens = flow().run("student", "devpro", new Scope("openid"));

		HttpResponse<String> response = requestGreeting(tokens.accessToken());

		// A perfectly valid token that simply was not asked to cover this resource.
		assertThat(response.statusCode()).isEqualTo(403);
		assertThat(authenticateHeaderOf(response)).contains("error=\"insufficient_scope\"");
	}

	private AuthorizationCodeFlow flow()
	{
		return new AuthorizationCodeFlow(baseUri(), "devpro-client", "devpro-secret", REDIRECT_URI);
	}

	private HttpResponse<String> requestGreeting(String accessToken) throws Exception
	{
		HttpRequest.Builder request =
			HttpRequest.newBuilder(baseUri().resolve("/api/greeting")).GET();
		if (accessToken != null)
			request.header("Authorization", "Bearer " + accessToken);
		return client.send(request.build(), BodyHandlers.ofString());
	}

	private String authenticateHeaderOf(HttpResponse<String> response)
	{
		return response.headers().firstValue("WWW-Authenticate").orElseThrow();
	}

	private URI baseUri()
	{
		return URI.create("http://localhost:" + port);
	}
}
