package nl.topicus.devpro.authenticator.server;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Set;

import com.nimbusds.oauth2.sdk.AuthorizationCode;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;
import org.junit.jupiter.api.Test;

class AuthorizationCodeStoreTest
{
	private static final AuthorizationServerSettings SETTINGS =
		AuthorizationServerSettings.forIssuer(URI.create("https://authenticator.example"));

	private static final Instant NOW = Instant.parse("2026-09-21T12:00:00Z");

	private final MutableClock clock = new MutableClock(NOW);

	private final AuthorizationCodeStore store = new AuthorizationCodeStore(SETTINGS, clock);

	@Test
	void anIssuedCodeCanBeRedeemedOnce()
	{
		AuthorizationCode code = store.issue(pendingAuthorization());

		assertThat(store.consume(code)).isPresent();
		assertThat(store.consume(code)).isEmpty();
	}

	@Test
	void anExpiredCodeCannotBeRedeemed()
	{
		AuthorizationCode code = store.issue(pendingAuthorization());

		clock.advance(SETTINGS.authorizationCodeLifetime().plusSeconds(1));

		assertThat(store.consume(code)).isEmpty();
	}

	@Test
	void anUnknownCodeCannotBeRedeemed()
	{
		assertThat(store.consume(new AuthorizationCode("not-a-code"))).isEmpty();
	}

	private PendingAuthorization pendingAuthorization()
	{
		return new PendingAuthorization("student", "devpro-client",
			URI.create("https://client.example/callback"), Set.of("openid"), null, null,
			clock.instant());
	}

	private static class MutableClock extends Clock
	{
		private Instant instant;

		public MutableClock(Instant instant)
		{
			this.instant = instant;
		}

		public void advance(Duration amount)
		{
			instant = instant.plus(amount);
		}

		@Override
		public Instant instant()
		{
			return instant;
		}

		@Override
		public ZoneId getZone()
		{
			return ZoneOffset.UTC;
		}

		@Override
		public Clock withZone(ZoneId zone)
		{
			return this;
		}
	}
}
