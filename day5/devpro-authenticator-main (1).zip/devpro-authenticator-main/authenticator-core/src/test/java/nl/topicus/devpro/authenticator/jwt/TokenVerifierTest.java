package nl.topicus.devpro.authenticator.jwt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import java.net.URI;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Set;

import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.PlainJWT;
import com.nimbusds.jwt.SignedJWT;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;
import org.junit.jupiter.api.Test;

/**
 * What an access token is worth comes down to what the verifier refuses, so most of these tests are
 * about tokens that must not be accepted.
 */
class TokenVerifierTest
{
	private static final AuthorizationServerSettings SETTINGS =
		AuthorizationServerSettings.forIssuer(URI.create("https://authenticator.example"));

	private static final Instant NOW = Instant.parse("2026-09-21T12:00:00Z");

	private static final String SUBJECT = "student";

	private static final String CLIENT_ID = "devpro-client";

	private final SigningKey signingKey = SigningKey.generate();

	private final TokenIssuer issuer = new TokenIssuer(SETTINGS, signingKey, fixedClock(NOW));

	private final TokenVerifier verifier =
		new TokenVerifier(SETTINGS, signingKey.publicKeys(), fixedClock(NOW));

	@Test
	void anIssuedAccessTokenVerifies() throws Exception
	{
		String token = issuer.issueAccessToken(SUBJECT, CLIENT_ID, Set.of("greeting.read"));

		VerifiedAccessToken verified = verifier.verifyAccessToken(token);

		assertThat(verified.subject()).isEqualTo(SUBJECT);
		assertThat(verified.clientId()).isEqualTo(CLIENT_ID);
		assertThat(verified.hasScope("greeting.read")).isTrue();
		assertThat(verified.hasScope("something.else")).isFalse();
		assertThat(verified.expiresAt()).isEqualTo(NOW.plus(SETTINGS.accessTokenLifetime()));
	}

	@Test
	void aTokenSignedWithAnotherKeyIsRefused()
	{
		TokenIssuer impostor = new TokenIssuer(SETTINGS, SigningKey.generate(), fixedClock(NOW));

		assertRefused(impostor.issueAccessToken(SUBJECT, CLIENT_ID, Set.of("greeting.read")));
	}

	@Test
	void aTokenWithAnEditedSubjectIsRefused() throws Exception
	{
		String token = issuer.issueAccessToken(SUBJECT, CLIENT_ID, Set.of("greeting.read"));
		String[] parts = token.split("\\.");
		JWTClaimsSet edited = new JWTClaimsSet.Builder(SignedJWT.parse(token).getJWTClaimsSet())
			.subject("administrator")
			.build();

		assertRefused(parts[0] + "." + edited.toPayload().toBase64URL() + "." + parts[2]);
	}

	@Test
	void anUnsignedTokenIsRefused()
	{
		JWTClaimsSet claims = new JWTClaimsSet.Builder().issuer(SETTINGS.issuer().toString())
			.subject("administrator")
			.audience(SETTINGS.issuer().toString())
			.build();

		assertRefused(new PlainJWT(claims).serialize());
	}

	@Test
	void anExpiredTokenIsRefused()
	{
		String token = issuer.issueAccessToken(SUBJECT, CLIENT_ID, Set.of("greeting.read"));
		TokenVerifier later = new TokenVerifier(SETTINGS, signingKey.publicKeys(),
			fixedClock(NOW.plus(SETTINGS.accessTokenLifetime()).plusSeconds(60)));

		assertThatExceptionOfType(TokenValidationException.class)
			.isThrownBy(() -> later.verifyAccessToken(token));
	}

	@Test
	void anIdTokenIsNotAnAccessToken()
	{
		assertRefused(issuer.issueIdToken(SUBJECT, CLIENT_ID, "nonce-value", NOW));
	}

	private void assertRefused(String token)
	{
		assertThatExceptionOfType(TokenValidationException.class)
			.isThrownBy(() -> verifier.verifyAccessToken(token));
	}

	private static Clock fixedClock(Instant instant)
	{
		return Clock.fixed(instant, ZoneOffset.UTC);
	}
}
