package nl.topicus.devpro.authenticator.server;

import java.net.URI;
import java.time.Clock;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;

import com.nimbusds.oauth2.sdk.AuthorizationCode;
import com.nimbusds.oauth2.sdk.AuthorizationErrorResponse;
import com.nimbusds.oauth2.sdk.AuthorizationRequest;
import com.nimbusds.oauth2.sdk.AuthorizationSuccessResponse;
import com.nimbusds.oauth2.sdk.ErrorObject;
import com.nimbusds.oauth2.sdk.OAuth2Error;
import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.ResponseType;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.pkce.CodeChallenge;
import com.nimbusds.oauth2.sdk.pkce.CodeChallengeMethod;
import com.nimbusds.openid.connect.sdk.AuthenticationRequest;
import com.nimbusds.openid.connect.sdk.Nonce;
import com.nimbusds.openid.connect.sdk.OIDCScopeValue;

/**
 * The rules of the authorization endpoint: which requests are acceptable, and where the browser is
 * sent once the user has proved who they are. Knows nothing about how the login screen is rendered
 * or which web framework delivered the request.
 */
public class AuthorizationEndpointService
{
	private final ClientRegistry clients;

	private final AuthorizationCodeStore codes;

	private final Clock clock;

	public AuthorizationEndpointService(ClientRegistry clients, AuthorizationCodeStore codes,
			Clock clock)
	{
		this.clients = clients;
		this.codes = codes;
		this.clock = clock;
	}

	/**
	 * Reads the query string of an authorization request. An OpenID Connect request is the same
	 * request with extra parameters, so which class it parses into depends on the requested scopes.
	 */
	public AuthorizationRequest parse(String query) throws OAuth2RequestException
	{
		try
		{
			AuthorizationRequest request = AuthorizationRequest.parse(query == null ? "" : query);
			if (request.getScope() != null
				&& request.getScope().contains(OIDCScopeValue.OPENID.getValue()))
				return AuthenticationRequest.parse(query);
			return request;
		}
		catch (ParseException e)
		{
			// A request this broken has no trustworthy redirect URI to send the error to.
			throw OAuth2RequestException
				.reportToUser(OAuth2Error.INVALID_REQUEST.setDescription(e.getMessage()));
		}
	}

	public ValidatedAuthorizationRequest validate(AuthorizationRequest request)
			throws OAuth2RequestException
	{
		RegisteredClient client = clients.findById(request.getClientID().getValue())
			.orElseThrow(() -> OAuth2RequestException
				.reportToUser(OAuth2Error.INVALID_REQUEST.setDescription("Unknown client_id")));

		URI redirectUri = request.getRedirectionURI();
		if (!client.hasRedirectUri(redirectUri))
			throw OAuth2RequestException.reportToUser(
				OAuth2Error.INVALID_REQUEST.setDescription("Unregistered redirect_uri"));

		// From here on the redirect URI is known to belong to the client, so errors can be reported
		// to the client instead of to the user staring at the browser.
		if (!ResponseType.CODE.equals(request.getResponseType()))
			throw reportToClient(OAuth2Error.UNSUPPORTED_RESPONSE_TYPE, request);

		Set<String> scopes = scopesOf(request.getScope());
		if (!client.allowsScopes(scopes))
			throw reportToClient(OAuth2Error.INVALID_SCOPE, request);

		CodeChallenge codeChallenge = verifyPkce(request, client);

		return new ValidatedAuthorizationRequest(client, redirectUri, scopes, request.getState(),
			nonceOf(request), codeChallenge);
	}

	/**
	 * Issues the authorization code for an approved request and returns the URI the browser should
	 * be sent to. The code itself carries no information: everything the token endpoint needs is
	 * parked in the store under it.
	 */
	public URI approve(ValidatedAuthorizationRequest request, String subject)
	{
		AuthorizationCode code = codes.issue(
			new PendingAuthorization(subject, request.client().clientId(), request.redirectUri(),
				request.scopes(), request.nonce(), request.codeChallenge(), clock.instant()));
		return new AuthorizationSuccessResponse(request.redirectUri(), code, null, request.state(),
			null).toURI();
	}

	/**
	 * The URI a rejected request should be redirected to, or empty when the error may not leave
	 * this server.
	 */
	public Optional<URI> rejection(OAuth2RequestException failure)
	{
		return failure.redirectUri()
			.map(uri -> new AuthorizationErrorResponse(uri, failure.error(), failure.state(), null)
				.toURI());
	}

	/**
	 * PKCE binds the authorization code to whoever started the flow: only the holder of the code
	 * verifier that produced this challenge can redeem the code, so a stolen code is worthless.
	 */
	private CodeChallenge verifyPkce(AuthorizationRequest request, RegisteredClient client)
			throws OAuth2RequestException
	{
		CodeChallenge codeChallenge = request.getCodeChallenge();
		if (codeChallenge == null)
		{
			if (client.requirePkce())
				throw reportToClient(
					OAuth2Error.INVALID_REQUEST.setDescription("code_challenge is required"),
					request);
			return null;
		}
		// The "plain" method sends the verifier itself as the challenge, which protects against
		// nothing if the authorization request was observed.
		if (!CodeChallengeMethod.S256.equals(request.getCodeChallengeMethod()))
			throw reportToClient(OAuth2Error.INVALID_REQUEST
				.setDescription("Only the S256 code_challenge_method is supported"), request);
		return codeChallenge;
	}

	private OAuth2RequestException reportToClient(ErrorObject error, AuthorizationRequest request)
	{
		return OAuth2RequestException.reportToClient(error, request.getRedirectionURI(),
			request.getState());
	}

	private Set<String> scopesOf(Scope scope)
	{
		return scope == null ? Set.of() : new LinkedHashSet<>(scope.toStringList());
	}

	private Nonce nonceOf(AuthorizationRequest request)
	{
		return request instanceof AuthenticationRequest openIdRequest ? openIdRequest.getNonce()
			: null;
	}
}
