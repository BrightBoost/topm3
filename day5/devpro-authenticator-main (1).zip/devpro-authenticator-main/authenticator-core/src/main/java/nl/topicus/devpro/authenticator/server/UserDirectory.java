package nl.topicus.devpro.authenticator.server;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Where the authorization endpoint looks up who is logging in. This is the seam to plug a real user
 * store into: nothing outside this class knows how a user proves their identity.
 */
public class UserDirectory
{
	private final Map<String, UserAccount> accountsByUsername;

	public UserDirectory(Collection<UserAccount> accounts)
	{
		this.accountsByUsername = accounts.stream()
			.collect(Collectors.toMap(UserAccount::username, Function.identity(),
				(first, second) -> first, LinkedHashMap::new));
	}

	/**
	 * An unknown username and a wrong password give the same empty result on purpose: telling them
	 * apart hands out a list of valid usernames.
	 */
	public Optional<UserAccount> authenticate(String username, String password)
	{
		return Optional.ofNullable(accountsByUsername.get(username))
			.filter(account -> account.matchesPassword(password));
	}
}
