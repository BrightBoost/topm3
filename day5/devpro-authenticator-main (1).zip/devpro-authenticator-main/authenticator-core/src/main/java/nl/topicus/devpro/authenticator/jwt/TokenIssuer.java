package nl.topicus.devpro.authenticator.jwt;

import java.time.Clock;
import java.time.Instant;
import java.util.Date;
import java.util.Set;
import java.util.UUID;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;

/**
 * Fills and signs the two kinds of token this server hands out. An access token says what the
 * bearer may do at the resource server; an id token says who logged in and is meant for the client
 * application itself. They are deliberately not interchangeable.
 */
public class TokenIssuer
{
	/**
	 * Marks a JWT as an access token (RFC 9068). {@link TokenVerifier} insists on it, which is what
	 * stops an id token from being presented as an access token.
	 */
	public static final JOSEObjectType ACCESS_TOKEN_TYPE = new JOSEObjectType("at+jwt");

	public static final String CLIENT_ID_CLAIM = "client_id";

	public static final String SCOPE_CLAIM = "scope";

	public static final String NONCE_CLAIM = "nonce";

	public static final String AUTHENTICATION_TIME_CLAIM = "auth_time";

	private final AuthorizationServerSettings settings;

	private final SigningKey signingKey;

	private final Clock clock;

	public TokenIssuer(AuthorizationServerSettings settings, SigningKey signingKey, Clock clock)
	{
		this.settings = settings;
		this.signingKey = signingKey;
		this.clock = clock;
	}

	public String issueAccessToken(String subject, String clientId, Set<String> scopes)
	{
		Instant now = clock.instant();
		JWTClaimsSet claims = new JWTClaimsSet.Builder().issuer(settings.issuer().toString())
			.subject(subject)
			// This server is its own resource server, so it is also the audience of its access
			// tokens. A token minted for someone else must not be accepted here.
			.audience(settings.issuer().toString())
			.claim(CLIENT_ID_CLAIM, clientId)
			.claim(SCOPE_CLAIM, String.join(" ", scopes))
			.jwtID(UUID.randomUUID().toString())
			.issueTime(Date.from(now))
			.notBeforeTime(Date.from(now))
			.expirationTime(Date.from(now.plus(settings.accessTokenLifetime())))
			.build();
		return sign(claims, ACCESS_TOKEN_TYPE);
	}

	/**
	 * The id token is addressed to the client that started the flow, hence the client id as
	 * audience. The nonce ties it to that one authorization request so a replayed id token from an
	 * earlier login is detectable.
	 */
	public String issueIdToken(String subject, String clientId, String nonce,
			Instant authenticatedAt)
	{
		Instant now = clock.instant();
		JWTClaimsSet.Builder claims =
			new JWTClaimsSet.Builder().issuer(settings.issuer().toString())
				.subject(subject)
				.audience(clientId)
				.issueTime(Date.from(now))
				.expirationTime(Date.from(now.plus(settings.idTokenLifetime())))
				.claim(AUTHENTICATION_TIME_CLAIM, authenticatedAt.getEpochSecond());
		if (nonce != null)
			claims.claim(NONCE_CLAIM, nonce);
		return sign(claims.build(), JOSEObjectType.JWT);
	}

	private String sign(JWTClaimsSet claims, JOSEObjectType type)
	{
		JWSHeader header = new JWSHeader.Builder(signingKey.algorithm()).type(type)
			.keyID(signingKey.keyId())
			.build();
		SignedJWT token = new SignedJWT(header, claims);
		try
		{
			token.sign(signingKey.signer());
		}
		catch (JOSEException e)
		{
			throw new IllegalStateException("Could not sign a token", e);
		}
		return token.serialize();
	}
}
