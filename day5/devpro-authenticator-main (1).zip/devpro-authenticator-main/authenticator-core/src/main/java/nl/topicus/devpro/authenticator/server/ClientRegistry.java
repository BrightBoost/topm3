package nl.topicus.devpro.authenticator.server;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * The clients this server knows. Replace this with whatever the application already uses to store
 * its integrations; nothing else in the flow depends on where the registrations live.
 */
public class ClientRegistry
{
	private final Map<String, RegisteredClient> clientsById;

	public ClientRegistry(Collection<RegisteredClient> clients)
	{
		this.clientsById = clients.stream()
			.collect(Collectors.toMap(RegisteredClient::clientId, Function.identity(),
				(first, second) -> first, LinkedHashMap::new));
	}

	public Optional<RegisteredClient> findById(String clientId)
	{
		return Optional.ofNullable(clientsById.get(clientId));
	}

	/**
	 * Every scope any registered client may ask for, which is what the discovery document
	 * advertises as supported.
	 */
	public Set<String> knownScopes()
	{
		Set<String> scopes = new LinkedHashSet<>();
		clientsById.values().forEach(client -> scopes.addAll(client.scopes()));
		return scopes;
	}
}
