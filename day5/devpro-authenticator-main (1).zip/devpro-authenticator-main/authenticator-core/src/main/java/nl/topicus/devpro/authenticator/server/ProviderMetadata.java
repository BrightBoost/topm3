package nl.topicus.devpro.authenticator.server;

import java.util.Collection;
import java.util.List;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.oauth2.sdk.GrantType;
import com.nimbusds.oauth2.sdk.ResponseType;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.auth.ClientAuthenticationMethod;
import com.nimbusds.oauth2.sdk.id.Issuer;
import com.nimbusds.oauth2.sdk.pkce.CodeChallengeMethod;
import com.nimbusds.openid.connect.sdk.SubjectType;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;

/**
 * Builds the document served at /.well-known/openid-configuration. It is what lets a client library
 * configure itself from the issuer URL alone, instead of being told every endpoint by hand.
 */
public class ProviderMetadata
{
	private ProviderMetadata()
	{
	}

	public static OIDCProviderMetadata of(AuthorizationServerSettings settings,
			Collection<String> supportedScopes)
	{
		OIDCProviderMetadata metadata = new OIDCProviderMetadata(new Issuer(settings.issuer()),
			List.of(SubjectType.PUBLIC), settings.jwkSetEndpoint());
		metadata.setAuthorizationEndpointURI(settings.authorizationEndpoint());
		metadata.setTokenEndpointURI(settings.tokenEndpoint());
		metadata.setScopes(new Scope(supportedScopes.toArray(String[]::new)));
		metadata.setResponseTypes(List.of(ResponseType.CODE));
		metadata.setGrantTypes(List.of(GrantType.AUTHORIZATION_CODE));
		metadata.setTokenEndpointAuthMethods(List.of(ClientAuthenticationMethod.CLIENT_SECRET_BASIC,
			ClientAuthenticationMethod.CLIENT_SECRET_POST));
		metadata.setCodeChallengeMethods(List.of(CodeChallengeMethod.S256));
		metadata.setIDTokenJWSAlgs(List.of(JWSAlgorithm.RS256));
		return metadata;
	}
}
