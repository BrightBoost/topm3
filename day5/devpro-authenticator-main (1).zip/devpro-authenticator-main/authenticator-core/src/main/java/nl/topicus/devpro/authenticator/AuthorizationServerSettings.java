package nl.topicus.devpro.authenticator;

import java.net.URI;
import java.time.Duration;

/**
 * Everything the authorization server needs to know about itself. The issuer is both the identity
 * that ends up in every token as the "iss" claim and the base of all endpoint URLs, so changing it
 * invalidates every token issued under the old value.
 */
public record AuthorizationServerSettings(URI issuer, Duration accessTokenLifetime,
		Duration idTokenLifetime, Duration authorizationCodeLifetime, Duration clockSkew)
{
	/**
	 * The authorization code lives far longer than it should, so that the flow can be walked by hand
	 * with a browser and a terminal. A code is redeemed by a machine within a second or two, and RFC
	 * 6749 recommends keeping it under ten minutes.
	 */
	public static AuthorizationServerSettings forIssuer(URI issuer)
	{
		return new AuthorizationServerSettings(issuer, Duration.ofMinutes(5), Duration.ofMinutes(5),
			Duration.ofMinutes(5), Duration.ofSeconds(10));
	}

	public URI authorizationEndpoint()
	{
		return endpoint("/oauth2/authorize");
	}

	public URI tokenEndpoint()
	{
		return endpoint("/oauth2/token");
	}

	public URI jwkSetEndpoint()
	{
		return endpoint("/oauth2/jwks");
	}

	private URI endpoint(String path)
	{
		String base = issuer.toString();
		if (base.endsWith("/"))
			base = base.substring(0, base.length() - 1);
		return URI.create(base + path);
	}
}
