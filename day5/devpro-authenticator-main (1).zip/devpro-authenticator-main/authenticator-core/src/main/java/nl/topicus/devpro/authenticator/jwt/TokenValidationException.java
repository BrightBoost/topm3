package nl.topicus.devpro.authenticator.jwt;

/**
 * Thrown for every reason a token is not acceptable. It carries no detail about which check failed
 * beyond its message, because a caller is not supposed to treat the reasons differently.
 */
public class TokenValidationException extends Exception
{
	private static final long serialVersionUID = 1L;

	public TokenValidationException(String message)
	{
		super(message);
	}

	public TokenValidationException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
