package nl.topicus.devpro.authenticator.resource;

import java.io.IOException;
import java.util.Set;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.token.BearerTokenError;
import nl.topicus.devpro.authenticator.jwt.TokenValidationException;
import nl.topicus.devpro.authenticator.jwt.TokenVerifier;
import nl.topicus.devpro.authenticator.jwt.VerifiedAccessToken;

/**
 * The resource server half: everything behind this filter can assume a verified access token, and
 * nothing behind it has to know what a JWT is. A plain servlet filter, so it works the same in
 * Spring Boot, Quarkus or on an application server.
 */
public class BearerTokenFilter implements Filter
{
	public static final String TOKEN_ATTRIBUTE = VerifiedAccessToken.class.getName();

	private static final String AUTHORIZATION_HEADER = "Authorization";

	private static final String BEARER_PREFIX = "Bearer ";

	private final TokenVerifier verifier;

	private final String realm;

	private final Set<String> requiredScopes;

	public BearerTokenFilter(TokenVerifier verifier, String realm, Set<String> requiredScopes)
	{
		this.verifier = verifier;
		this.realm = realm;
		this.requiredScopes = Set.copyOf(requiredScopes);
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException
	{
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;

		String header = httpRequest.getHeader(AUTHORIZATION_HEADER);
		if (header == null
			|| !header.regionMatches(true, 0, BEARER_PREFIX, 0, BEARER_PREFIX.length()))
		{
			// A request without credentials is answered without an error code, so a client can tell
			// "you did not authenticate" apart from "your token is no good" (RFC 6750).
			refuse(httpResponse, BearerTokenError.MISSING_TOKEN);
			return;
		}

		VerifiedAccessToken token;
		try
		{
			token = verifier.verifyAccessToken(header.substring(BEARER_PREFIX.length()).trim());
		}
		catch (TokenValidationException e)
		{
			refuse(httpResponse, BearerTokenError.INVALID_TOKEN.setDescription(e.getMessage()));
			return;
		}

		if (!token.scopes().containsAll(requiredScopes))
		{
			// A valid token that is simply not allowed to do this: 403, and the response says which
			// scope would have been needed.
			refuse(httpResponse, BearerTokenError.INSUFFICIENT_SCOPE
				.setScope(new Scope(requiredScopes.toArray(String[]::new))));
			return;
		}

		httpRequest.setAttribute(TOKEN_ATTRIBUTE, token);
		chain.doFilter(request, response);
	}

	/**
	 * The token that got this request past the filter.
	 *
	 * @throws IllegalStateException
	 *             when called for a request that did not pass through this filter.
	 */
	public static VerifiedAccessToken tokenOf(ServletRequest request)
	{
		if (!(request.getAttribute(TOKEN_ATTRIBUTE) instanceof VerifiedAccessToken token))
			throw new IllegalStateException(
				"No verified access token: is this resource behind the BearerTokenFilter?");
		return token;
	}

	/**
	 * RFC 6750 carries the reason in the WWW-Authenticate header rather than in a response body,
	 * which is also why the error object knows its own status code.
	 */
	private void refuse(HttpServletResponse response, BearerTokenError error) throws IOException
	{
		BearerTokenError refusal = error.setRealm(realm);
		response.setStatus(refusal.getHTTPStatusCode());
		response.setHeader("WWW-Authenticate", refusal.toWWWAuthenticateHeader());
		response.flushBuffer();
	}
}
