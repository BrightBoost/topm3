package nl.topicus.devpro.authenticator.jwt;

import java.time.Instant;
import java.util.Set;

import com.nimbusds.jwt.JWTClaimsSet;

/**
 * The outcome of a successful verification: who the token is about, which client asked for it and
 * what it is allowed to do. Only ever created by {@link TokenVerifier}, so holding one is proof
 * that the signature and all claims checked out.
 */
public record VerifiedAccessToken(String subject, String clientId, Set<String> scopes,
		Instant expiresAt, JWTClaimsSet claims)
{
	public VerifiedAccessToken
	{
		scopes = Set.copyOf(scopes);
	}

	public boolean hasScope(String scope)
	{
		return scopes.contains(scope);
	}
}
