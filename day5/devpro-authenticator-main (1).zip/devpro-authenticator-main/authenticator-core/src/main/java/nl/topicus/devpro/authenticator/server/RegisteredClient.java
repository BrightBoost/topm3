package nl.topicus.devpro.authenticator.server;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Set;

/**
 * An application that is allowed to ask this server for tokens. Registration is what makes the
 * redirect URI check possible, and that check is the only thing keeping an authorization code from
 * being delivered to an address an attacker chose.
 * <p>
 * The secret is kept as-is because this registry only exists to make the flow runnable. A real
 * registry stores a salted hash, exactly like it would for a user password.
 */
public record RegisteredClient(String clientId, String clientSecret, Set<URI> redirectUris,
		Set<String> scopes, boolean requirePkce)
{
	public RegisteredClient
	{
		redirectUris = Set.copyOf(redirectUris);
		scopes = Set.copyOf(scopes);
	}

	/**
	 * Registered redirect URIs are compared whole, never by prefix or host: a client registered for
	 * "https://app.example/callback" must not be able to redirect to "https://app.example/callback
	 * /../../elsewhere".
	 */
	public boolean hasRedirectUri(URI candidate)
	{
		return candidate != null && redirectUris.contains(candidate);
	}

	public boolean matchesSecret(String candidate)
	{
		if (candidate == null)
			return false;
		// Compares in constant time for equal length inputs, so a wrong secret does not leak how
		// many of its leading characters were right.
		return MessageDigest.isEqual(clientSecret.getBytes(StandardCharsets.UTF_8),
			candidate.getBytes(StandardCharsets.UTF_8));
	}

	public boolean allowsScopes(Set<String> requested)
	{
		return scopes.containsAll(requested);
	}
}
