package nl.topicus.devpro.authenticator.server;

import java.net.URI;
import java.util.Optional;

import com.nimbusds.oauth2.sdk.ErrorObject;
import com.nimbusds.oauth2.sdk.id.State;

/**
 * A rejected authorization request, plus the decision of where the rejection may be reported.
 * <p>
 * An error can only be sent to a redirect URI once that URI has been recognised as registered for
 * the client. Before that point the server has nothing but an address the caller supplied, and
 * forwarding anything there would turn the authorization endpoint into an open redirector.
 */
public class OAuth2RequestException extends Exception
{
	private static final long serialVersionUID = 1L;

	private final ErrorObject error;

	private final URI redirectUri;

	private final State state;

	private OAuth2RequestException(ErrorObject error, URI redirectUri, State state)
	{
		super(error.getCode() + ": " + error.getDescription());
		this.error = error;
		this.redirectUri = redirectUri;
		this.state = state;
	}

	/**
	 * For errors found before the redirect URI could be trusted; the user has to be told by the
	 * authorization server itself.
	 */
	public static OAuth2RequestException reportToUser(ErrorObject error)
	{
		return new OAuth2RequestException(error, null, null);
	}

	public static OAuth2RequestException reportToClient(ErrorObject error, URI redirectUri,
			State state)
	{
		return new OAuth2RequestException(error, redirectUri, state);
	}

	public ErrorObject error()
	{
		return error;
	}

	public Optional<URI> redirectUri()
	{
		return Optional.ofNullable(redirectUri);
	}

	public State state()
	{
		return state;
	}
}
