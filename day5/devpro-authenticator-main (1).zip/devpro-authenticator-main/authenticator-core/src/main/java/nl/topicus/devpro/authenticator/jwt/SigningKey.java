package nl.topicus.devpro.authenticator.jwt;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;

/**
 * The RSA key pair that tokens are signed with. Only the private half signs; the public half is
 * published as a JWK set, so anything that wants to verify a token needs no secret from us.
 */
public final class SigningKey
{
	private static final int KEY_SIZE_BITS = 2048;

	private final RSAKey keyPair;

	private SigningKey(RSAKey keyPair)
	{
		this.keyPair = keyPair;
	}

	/**
	 * Generates a fresh key pair, which means a restart invalidates every token issued before it.
	 * Acceptable here, never acceptable in a real deployment: load the key from a keystore instead.
	 */
	public static SigningKey generate()
	{
		try
		{
			return new SigningKey(new RSAKeyGenerator(KEY_SIZE_BITS).keyUse(KeyUse.SIGNATURE)
				.algorithm(JWSAlgorithm.RS256)
				.keyIDFromThumbprint(true)
				.generate());
		}
		catch (JOSEException e)
		{
			throw new IllegalStateException("Could not generate an RSA signing key", e);
		}
	}

	public static SigningKey of(RSAKey keyPair)
	{
		return new SigningKey(keyPair);
	}

	/**
	 * Identifies this key in the "kid" header of every token it signs, so a verifier can pick the
	 * right key out of the JWK set and key rotation does not need a flag day.
	 */
	public String keyId()
	{
		return keyPair.getKeyID();
	}

	public JWSAlgorithm algorithm()
	{
		return JWSAlgorithm.RS256;
	}

	public JWSSigner signer()
	{
		try
		{
			return new RSASSASigner(keyPair);
		}
		catch (JOSEException e)
		{
			throw new IllegalStateException("Could not create a signer for key " + keyId(), e);
		}
	}

	public JWKSet publicKeys()
	{
		return new JWKSet(keyPair).toPublicJWKSet();
	}
}
