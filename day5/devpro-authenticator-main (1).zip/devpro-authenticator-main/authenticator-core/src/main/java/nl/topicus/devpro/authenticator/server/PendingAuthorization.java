package nl.topicus.devpro.authenticator.server;

import java.net.URI;
import java.time.Instant;
import java.util.Set;

import com.nimbusds.oauth2.sdk.pkce.CodeChallenge;
import com.nimbusds.openid.connect.sdk.Nonce;

/**
 * Everything the authorization endpoint decided, parked under an authorization code until the
 * client comes back to the token endpoint to collect it. The redirect URI and the PKCE challenge
 * are kept because the token endpoint has to check them against what the client claims there.
 */
public record PendingAuthorization(String subject, String clientId, URI redirectUri,
		Set<String> scopes, Nonce nonce, CodeChallenge codeChallenge, Instant authenticatedAt)
{
	public PendingAuthorization
	{
		scopes = Set.copyOf(scopes);
	}
}
