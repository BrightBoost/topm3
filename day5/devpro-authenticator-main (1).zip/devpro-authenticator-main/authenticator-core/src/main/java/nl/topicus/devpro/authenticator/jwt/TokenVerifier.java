package nl.topicus.devpro.authenticator.jwt;

import java.text.ParseException;
import java.time.Clock;
import java.time.Instant;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import com.nimbusds.jwt.SignedJWT;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;

/**
 * Turns the string in an Authorization header back into something trustworthy, or refuses. This is
 * the class a resource server needs; it holds only public keys, so it can run somewhere that is not
 * allowed to issue tokens at all.
 */
public class TokenVerifier
{
	private final AuthorizationServerSettings settings;

	private final JWKSet trustedKeys;

	private final Clock clock;

	/**
	 * @param trustedKeys
	 *            the public keys tokens may be signed with. A separately deployed resource server
	 *            would fetch these from the issuer's jwks_uri instead of being handed them.
	 */
	public TokenVerifier(AuthorizationServerSettings settings, JWKSet trustedKeys, Clock clock)
	{
		this.settings = settings;
		this.trustedKeys = trustedKeys;
		this.clock = clock;
	}

	public VerifiedAccessToken verifyAccessToken(String serializedToken)
			throws TokenValidationException
	{
		SignedJWT token = parseSigned(serializedToken);
		requireAccessTokenType(token);
		verifySignature(token);

		JWTClaimsSet claims = claimsOf(token);
		verifyIssuerAndAudience(claims);
		verifyValidityPeriod(claims);
		if (claims.getSubject() == null)
			throw new TokenValidationException("Token has no subject");

		return new VerifiedAccessToken(claims.getSubject(),
			stringClaim(claims, TokenIssuer.CLIENT_ID_CLAIM), scopesOf(claims),
			claims.getExpirationTime().toInstant(), claims);
	}

	private SignedJWT parseSigned(String serializedToken) throws TokenValidationException
	{
		try
		{
			JWT token = JWTParser.parse(serializedToken);
			// An unsigned JWT parses perfectly well and claims whatever its holder wants it to.
			// Accepting one ("alg": "none") is the textbook way to lose all of this.
			if (!(token instanceof SignedJWT signedToken))
				throw new TokenValidationException("Token is not signed");
			return signedToken;
		}
		catch (ParseException e)
		{
			throw new TokenValidationException("Token is malformed", e);
		}
	}

	private void requireAccessTokenType(SignedJWT token) throws TokenValidationException
	{
		if (!TokenIssuer.ACCESS_TOKEN_TYPE.equals(token.getHeader().getType()))
			throw new TokenValidationException("Token is not an access token");
	}

	private void verifySignature(SignedJWT token) throws TokenValidationException
	{
		// The algorithm is pinned instead of read from the token: a verifier that trusts the header
		// can be talked into verifying an RS256 token as HS256, using the public key as the shared
		// secret - which the attacker has, because it is public.
		if (!signingAlgorithm().equals(token.getHeader().getAlgorithm()))
			throw new TokenValidationException(
				"Token is not signed with " + signingAlgorithm().getName());

		if (!(trustedKeys.getKeyByKeyId(token.getHeader().getKeyID()) instanceof RSAKey key))
			throw new TokenValidationException(
				"Token was signed with unknown key " + token.getHeader().getKeyID());

		try
		{
			if (!token.verify(new RSASSAVerifier(key)))
				throw new TokenValidationException("Token signature does not match");
		}
		catch (JOSEException e)
		{
			throw new TokenValidationException("Token signature could not be checked", e);
		}
	}

	private void verifyIssuerAndAudience(JWTClaimsSet claims) throws TokenValidationException
	{
		String expected = settings.issuer().toString();
		if (!expected.equals(claims.getIssuer()))
			throw new TokenValidationException("Token was issued by " + claims.getIssuer());

		List<String> audience = claims.getAudience();
		if (audience == null || !audience.contains(expected))
			throw new TokenValidationException("Token is not meant for " + expected);
	}

	private void verifyValidityPeriod(JWTClaimsSet claims) throws TokenValidationException
	{
		Instant now = clock.instant();
		if (claims.getExpirationTime() == null)
			throw new TokenValidationException("Token has no expiry");
		if (!now.minus(settings.clockSkew()).isBefore(claims.getExpirationTime().toInstant()))
			throw new TokenValidationException("Token expired at " + claims.getExpirationTime());
		if (claims.getNotBeforeTime() != null
			&& now.plus(settings.clockSkew()).isBefore(claims.getNotBeforeTime().toInstant()))
			throw new TokenValidationException(
				"Token is not valid before " + claims.getNotBeforeTime());
	}

	private JWSAlgorithm signingAlgorithm()
	{
		return JWSAlgorithm.RS256;
	}

	private JWTClaimsSet claimsOf(SignedJWT token) throws TokenValidationException
	{
		try
		{
			return token.getJWTClaimsSet();
		}
		catch (ParseException e)
		{
			throw new TokenValidationException("Token claims are malformed", e);
		}
	}

	private String stringClaim(JWTClaimsSet claims, String name) throws TokenValidationException
	{
		try
		{
			return claims.getStringClaim(name);
		}
		catch (ParseException e)
		{
			throw new TokenValidationException("Claim " + name + " is not a string", e);
		}
	}

	private Set<String> scopesOf(JWTClaimsSet claims) throws TokenValidationException
	{
		String scope = stringClaim(claims, TokenIssuer.SCOPE_CLAIM);
		if (scope == null || scope.isBlank())
			return Set.of();
		return new LinkedHashSet<>(Arrays.asList(scope.trim().split("\\s+")));
	}
}
