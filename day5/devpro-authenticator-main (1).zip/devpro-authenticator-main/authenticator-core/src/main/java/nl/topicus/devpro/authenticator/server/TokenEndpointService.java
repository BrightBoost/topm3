package nl.topicus.devpro.authenticator.server;

import java.util.Optional;

import com.nimbusds.oauth2.sdk.AuthorizationCodeGrant;
import com.nimbusds.oauth2.sdk.AuthorizationGrant;
import com.nimbusds.oauth2.sdk.ErrorObject;
import com.nimbusds.oauth2.sdk.GrantType;
import com.nimbusds.oauth2.sdk.OAuth2Error;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.TokenErrorResponse;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.auth.ClientAuthentication;
import com.nimbusds.oauth2.sdk.auth.PlainClientSecret;
import com.nimbusds.oauth2.sdk.pkce.CodeChallenge;
import com.nimbusds.oauth2.sdk.pkce.CodeChallengeMethod;
import com.nimbusds.oauth2.sdk.pkce.CodeVerifier;
import com.nimbusds.oauth2.sdk.token.BearerAccessToken;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponse;
import com.nimbusds.openid.connect.sdk.token.OIDCTokens;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;
import nl.topicus.devpro.authenticator.jwt.TokenIssuer;

/**
 * The rules of the token endpoint: turn an authorization code into tokens, or say no. Unlike the
 * authorization endpoint this one talks to the client application directly, so every refusal is an
 * ordinary JSON response instead of a redirect.
 */
public class TokenEndpointService
{
	private final AuthorizationServerSettings settings;

	private final ClientRegistry clients;

	private final AuthorizationCodeStore codes;

	private final TokenIssuer tokens;

	public TokenEndpointService(AuthorizationServerSettings settings, ClientRegistry clients,
			AuthorizationCodeStore codes, TokenIssuer tokens)
	{
		this.settings = settings;
		this.clients = clients;
		this.codes = codes;
		this.tokens = tokens;
	}

	public TokenResponse exchange(TokenRequest request)
	{
		Optional<RegisteredClient> authenticated = authenticateClient(request);
		if (authenticated.isEmpty())
			return new TokenErrorResponse(OAuth2Error.INVALID_CLIENT);
		RegisteredClient client = authenticated.get();

		AuthorizationGrant grant = request.getAuthorizationGrant();
		if (GrantType.REFRESH_TOKEN.equals(grant.getType()))
			return new TokenErrorResponse(OAuth2Error.UNSUPPORTED_GRANT_TYPE
				.setDescription("Implementing refresh_token is left as an exercise"));
		if (!(grant instanceof AuthorizationCodeGrant codeGrant))
			return new TokenErrorResponse(OAuth2Error.UNSUPPORTED_GRANT_TYPE);

		Optional<PendingAuthorization> consumed = codes.consume(codeGrant.getAuthorizationCode());
		if (consumed.isEmpty())
			return invalidGrant("Unknown, expired or already used authorization code");
		PendingAuthorization authorization = consumed.get();

		// The code was handed out to one client after one user logged in for one redirect URI. All
		// three have to still hold, or a code intercepted in a browser would be enough to get a
		// token somewhere else.
		if (!authorization.clientId().equals(client.clientId()))
			return invalidGrant("Authorization code was issued to another client");
		if (!authorization.redirectUri().equals(codeGrant.getRedirectionURI()))
			return invalidGrant("redirect_uri does not match the authorization request");

		ErrorObject pkceFailure = verifyCodeVerifier(authorization, codeGrant.getCodeVerifier());
		if (pkceFailure != null)
			return new TokenErrorResponse(pkceFailure);

		return issueTokens(authorization, client);
	}

	private TokenResponse issueTokens(PendingAuthorization authorization, RegisteredClient client)
	{
		BearerAccessToken accessToken = new BearerAccessToken(
			tokens.issueAccessToken(authorization.subject(), client.clientId(),
				authorization.scopes()),
			settings.accessTokenLifetime().toSeconds(),
			new Scope(authorization.scopes().toArray(String[]::new)));

		if (!authorization.scopes().contains("openid"))
			return new OIDCTokenResponse(new OIDCTokens(accessToken, null));

		String idToken = tokens.issueIdToken(authorization.subject(), client.clientId(),
			authorization.nonce() == null ? null : authorization.nonce().getValue(),
			authorization.authenticatedAt());
		return new OIDCTokenResponse(new OIDCTokens(idToken, accessToken, null));
	}

	/**
	 * Only the two client secret methods are accepted here. A public client, which has no secret to
	 * keep, would authenticate with PKCE alone - that is a deliberate omission, not an oversight.
	 */
	private Optional<RegisteredClient> authenticateClient(TokenRequest request)
	{
		ClientAuthentication authentication = request.getClientAuthentication();
		if (!(authentication instanceof PlainClientSecret credentials))
			return Optional.empty();
		return clients.findById(credentials.getClientID().getValue())
			.filter(client -> client.matchesSecret(credentials.getClientSecret().getValue()));
	}

	/**
	 * Recomputes the challenge from the verifier the client now presents. Storing only the hash is
	 * the point: an authorization request that was logged or observed gives away the challenge, and
	 * the challenge cannot be turned back into a verifier.
	 */
	private ErrorObject verifyCodeVerifier(PendingAuthorization authorization,
			CodeVerifier presented)
	{
		CodeChallenge expected = authorization.codeChallenge();
		if (expected == null)
			return null;
		if (presented == null)
			return OAuth2Error.INVALID_GRANT.setDescription("code_verifier is required");
		if (!expected.equals(CodeChallenge.compute(CodeChallengeMethod.S256, presented)))
			return OAuth2Error.INVALID_GRANT.setDescription("code_verifier does not match");
		return null;
	}

	private TokenResponse invalidGrant(String description)
	{
		return new TokenErrorResponse(OAuth2Error.INVALID_GRANT.setDescription(description));
	}
}
