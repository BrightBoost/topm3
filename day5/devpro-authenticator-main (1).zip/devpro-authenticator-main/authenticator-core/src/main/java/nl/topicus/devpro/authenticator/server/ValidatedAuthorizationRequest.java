package nl.topicus.devpro.authenticator.server;

import java.net.URI;
import java.util.Set;

import com.nimbusds.oauth2.sdk.id.State;
import com.nimbusds.oauth2.sdk.pkce.CodeChallenge;
import com.nimbusds.openid.connect.sdk.Nonce;

/**
 * An authorization request that passed every check, with the registered client and the redirect URI
 * resolved. Only ever created by {@link AuthorizationEndpointService}, so the login screen and the
 * code that follows it do not have to re-examine what the caller asked for.
 */
public record ValidatedAuthorizationRequest(RegisteredClient client, URI redirectUri,
		Set<String> scopes, State state, Nonce nonce, CodeChallenge codeChallenge)
{
	public ValidatedAuthorizationRequest
	{
		scopes = Set.copyOf(scopes);
	}

	/**
	 * OpenID Connect is a layer on top of OAuth 2.0: the "openid" scope is what turns an
	 * authorization request into a login request, and it is what earns the client an id token.
	 */
	public boolean isOpenIdRequest()
	{
		return scopes.contains("openid");
	}
}
