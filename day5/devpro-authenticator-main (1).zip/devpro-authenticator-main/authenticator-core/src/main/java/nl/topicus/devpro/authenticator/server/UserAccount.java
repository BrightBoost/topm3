package nl.topicus.devpro.authenticator.server;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * A user that can log in at the authorization endpoint. The password is stored in plain text
 * because this account only exists to make the flow runnable; a real directory stores a salted hash
 * (PBKDF2, bcrypt, argon2) and never the password itself.
 */
public record UserAccount(String username, String password, String displayName)
{
	public boolean matchesPassword(String candidate)
	{
		if (candidate == null)
			return false;
		return MessageDigest.isEqual(password.getBytes(StandardCharsets.UTF_8),
			candidate.getBytes(StandardCharsets.UTF_8));
	}
}
