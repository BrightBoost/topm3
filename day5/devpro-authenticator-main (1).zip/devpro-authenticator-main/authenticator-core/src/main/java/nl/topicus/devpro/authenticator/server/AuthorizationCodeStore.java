package nl.topicus.devpro.authenticator.server;

import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import com.nimbusds.oauth2.sdk.AuthorizationCode;
import nl.topicus.devpro.authenticator.AuthorizationServerSettings;

/**
 * Holds authorization codes between the authorization endpoint and the token endpoint. In memory,
 * so codes do not survive a restart and do not work across instances - a real deployment needs a
 * shared, expiring store.
 */
public class AuthorizationCodeStore
{
	private static final int CODE_LENGTH_BYTES = 32;

	private final Map<String, StoredCode> codesByValue = new ConcurrentHashMap<>();

	private final AuthorizationServerSettings settings;

	private final Clock clock;

	public AuthorizationCodeStore(AuthorizationServerSettings settings, Clock clock)
	{
		this.settings = settings;
		this.clock = clock;
	}

	public AuthorizationCode issue(PendingAuthorization authorization)
	{
		AuthorizationCode code = new AuthorizationCode(CODE_LENGTH_BYTES);
		codesByValue.put(code.getValue(), new StoredCode(authorization,
			clock.instant().plus(settings.authorizationCodeLifetime())));
		return code;
	}

	/**
	 * Removing the code before looking at it is what makes it single use: a code that is replayed,
	 * expired or simply unknown all end up as an empty result.
	 */
	public Optional<PendingAuthorization> consume(AuthorizationCode code)
	{
		if (code == null)
			return Optional.empty();
		StoredCode stored = codesByValue.remove(code.getValue());
		if (stored == null || stored.expiresAt().isBefore(clock.instant()))
			return Optional.empty();
		return Optional.of(stored.authorization());
	}

	private record StoredCode(PendingAuthorization authorization, Instant expiresAt)
	{
	}
}
