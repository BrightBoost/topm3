# DevPro Authenticator

A small OAuth 2.0 / OpenID Connect authorization server, plus one REST endpoint that only answers
when you present a token it issued. It exists to be read: every step of the authorization code flow
is a handful of lines you can follow, and the parts that are security relevant say why.

Take it as the starting point for your own backend. It is deliberately throw-away - see
[What is missing on purpose](#what-is-missing-on-purpose) before anything here goes near production.

## The flow

```mermaid
sequenceDiagram
    participant U as User (browser)
    participant C as Client application
    participant A as Authorization server
    participant R as Resource server

    C->>U: redirect to /oauth2/authorize<br/>client_id, redirect_uri, scope, state, code_challenge
    U->>A: GET /oauth2/authorize
    A->>U: login form
    U->>A: POST username + password
    A->>U: redirect to redirect_uri with code + state
    U->>C: code + state
    C->>A: POST /oauth2/token<br/>client_id + client_secret, code, code_verifier
    A->>C: access token (+ id token)
    C->>R: GET /api/greeting<br/>Authorization: Bearer ...
    R->>C: 200, because the signature and claims check out
```

The user proves who they are with a password; the client application proves who it is with its
secret; PKCE proves that whoever redeems the code is the one who started the flow. Three different
questions, three different answers - conflating them is where most homegrown OAuth goes wrong.

## Running it

```bash
mvn clean install
mvn -pl authenticator-app spring-boot:run
```

Registered for the demo, both hard coded in `AuthenticatorConfiguration`:

| | |
| --- | --- |
| client | `devpro-client` / `devpro-secret`, redirect URI `http://localhost:8080/callback` |
| user | `student` / `devpro` |
| scopes | `openid`, `greeting.read` |

### Walking the flow by hand

PKCE first: the verifier stays on your side, only its hash travels through the browser.

```bash
CODE_VERIFIER=$(openssl rand -hex 32)
CODE_CHALLENGE=$(printf %s "$CODE_VERIFIER" | openssl dgst -binary -sha256 | openssl base64 | tr '+/' '-_' | tr -d '=')
```

Open this in a browser and log in:

```
http://localhost:8080/oauth2/authorize?response_type=code&client_id=devpro-client&redirect_uri=http://localhost:8080/callback&scope=openid%20greeting.read&state=abc123&code_challenge=$CODE_CHALLENGE&code_challenge_method=S256
```

Nothing serves `/callback`, so the browser ends on an error page - the address bar holds the code.
You have five minutes to use it, it works once, and `redirect_uri` has to be byte for byte the one
from the request above. `state` stays behind: it is yours to compare against what came back, and the
token endpoint has no use for it.

Trade the code for tokens, then use one:

```bash
curl -s -u devpro-client:devpro-secret http://localhost:8080/oauth2/token \
  -d grant_type=authorization_code \
  -d code=<the code> \
  -d redirect_uri=http://localhost:8080/callback \
  -d code_verifier=$CODE_VERIFIER

curl -s -H "Authorization: Bearer <the access token>" http://localhost:8080/api/greeting
```

Paste the access token into <https://jwt.io> to see what you just verified. The public key it was
signed with is at <http://localhost:8080/oauth2/jwks>, and
<http://localhost:8080/.well-known/openid-configuration> is what a client library reads to configure
itself from the issuer URL alone.

## Where to start reading

Two modules, and the split is the point: everything that decides whether a token is any good is
plain Jakarta EE, so it moves to Quarkus or an application server unchanged. Only
`authenticator-app` knows about Spring.

**`authenticator-core`** - no framework, no web layer

| | |
| --- | --- |
| `jwt/TokenIssuer` | fills and signs access tokens and id tokens |
| `jwt/TokenVerifier` | the interesting half: everything a token has to survive to be believed |
| `jwt/SigningKey` | the RSA key pair, and the public JWK set derived from it |
| `server/AuthorizationEndpointService` | which authorization requests are acceptable, and what gets redirected where |
| `server/TokenEndpointService` | authenticates the client, redeems the code, hands out tokens |
| `server/AuthorizationCodeStore` | single use codes with a short life |
| `server/ClientRegistry`, `server/UserDirectory` | in memory stand-ins for whatever your application already has |
| `resource/BearerTokenFilter` | the resource server half: a servlet filter, nothing more |

**`authenticator-app`** - Spring Boot, thin on purpose

| | |
| --- | --- |
| `AuthenticatorConfiguration` | the only place the two halves are wired together |
| `AuthorizationEndpoint`, `TokenEndpoint` | HTTP in front of the two services above |
| `ProviderMetadataEndpoint` | discovery document and JWK set |
| `GreetingResource` | the protected endpoint, with no security logic in it at all |

Start at `ProtectedEndpointTest`: it drives the whole flow over real HTTP, so it is the shortest path
from "what happens" to "where that is implemented". `TokenVerifierTest` covers the other half - it is
mostly tokens that must be refused.

## Exercise: refresh tokens

The token endpoint recognises `grant_type=refresh_token` and answers `unsupported_grant_type`. Making
it work is a good way to find out whether the rest of this is clear:

1. Issue a refresh token next to the access token, with a much longer life.
2. Store it, so it can be revoked and so reuse of an already exchanged one is detectable.
3. Accept the grant: authenticate the client, look the token up, check it belongs to that client, and
   issue a new pair.
4. Rotate: the old refresh token must stop working the moment a new one is handed out.

`TokenIssuer` already marks access tokens with a `typ` header of `at+jwt` and `TokenVerifier` insists
on it, so a refresh token cannot be passed off as an access token by accident.

## What is missing on purpose

Everything below is a deliberate omission, not an oversight. Each one is a real requirement in a real
deployment:

- **Persistence.** Clients, users and authorization codes live in memory. The signing key is
  generated at startup, so every restart invalidates every token ever issued.
- **Password storage.** `UserAccount` compares plain text. A real directory stores a salted hash.
- **Client secret storage.** Same story in `RegisteredClient`.
- **A consent screen.** The user is never asked whether this client may have these scopes.
- **Public clients.** Only clients with a secret are supported. A single page app or a mobile app has
  no secret to keep and authenticates with PKCE alone.
- **Revocation, introspection, userinfo, logout.** None of these endpoints exist.
- **Key rotation.** One key, no overlap window, no way to retire it.
- **HTTPS.** Every URL here is plain HTTP, which makes every token in this README interceptable.

## Conventions

Java 21, Maven, Topicus code style. After editing Java, run:

```bash
mvn spotless:apply
```

The formatter config in `formatting/` is a copy of the one in `onderwijs-parent`, so this repository
builds without it.
